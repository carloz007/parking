package com.example.parking;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class cancelarReserva extends AppCompatActivity implements View.OnClickListener {

    Button btnCancelarC, btnRefrescarC;
    ListView listaCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancelar_reserva);

        //vincular elementos a variables
        btnCancelarC = (Button) findViewById(R.id.btnCancelarCancelar);
        btnRefrescarC = (Button) findViewById(R.id.btnRefrescarCancelar);
        listaCancelar = (ListView) findViewById(R.id.lstReservasCancelar);

        //Escuchar el evento click de las variables
        btnCancelarC.setOnClickListener(this);
        btnRefrescarC.setOnClickListener(this);

        //Toast toast1 = Toast.makeText(this,"REFRESCADO",Toast.LENGTH_SHORT);
        //toast1.show();
        listarReservas();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnCancelarCancelar:
                listaCancelar.setAdapter(null);
                break;
            case R.id.btnRefrescarCancelar:
                listarReservas();
                break;
        }//Fin de Switch
    }

    //public void listarReservas(){
    void listarReservas(){
        //Almacenar el sitio que contiene la BD
mensaje(MainActivity.userLogin);
        final String url="http://parking.scienceontheweb.net/index.php/reservas/"+MainActivity.userLogin;

        StringRequest stringRequest= new StringRequest(Request.Method.GET,url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    Log.i("======>",jsonArray.toString());

                    List<String> items = new ArrayList<>();

                    String estado="";
                    for (int i=0; i<jsonArray.length(); i++){
                        JSONObject object = jsonArray.getJSONObject(i);
                        //items.add(object.getString("codigo") + " / " +object.getString("clave"));
                        items.add("Fecha de reserva: "+object.getString("Dia-inicio") +
                                "\nHora de inicio: " +object.getString("Hora-inicio") +
                                "\nHora de fin: " +object.getString("Hora-fin"));
                    }//fin del for
                    //Crear adaptador
                    ArrayAdapter<String> adaptador = new ArrayAdapter<>(cancelarReserva.this, android.R.layout.simple_list_item_1, items);

                    //Se asigna el Adapter al ListView
                    listaCancelar.setAdapter(adaptador);
                } catch (JSONException e) {
                    Log.i("======>", e.getMessage());
                }
            }
        }, new Response.ErrorListener () {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.i("======>", error.toString());
            }
        } ); //Se cierra el StringRequest
        //Enviar solicitud
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    void mensaje(String msg){
        Toast toast = Toast.makeText(this,""+msg,Toast.LENGTH_LONG);
        toast.show();
    }
}
